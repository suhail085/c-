﻿using Microsoft.EntityFrameworkCore;
using CRUD2.Models;
namespace CRUD2.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> option):base(option) { }
        public DbSet<User> users { get; set; }
    }
}
