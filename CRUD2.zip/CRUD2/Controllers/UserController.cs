﻿using CRUD2.Models;
using CRUD2.Ripository.Contract;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace CRUD2.Controllers
{
    public class UserController : Controller
    {
        private readonly IUser userService;

        public Microsoft.AspNetCore.Hosting.IHostingEnvironment Environment { get; set; }

        public UserController(IUser service, Microsoft.AspNetCore.Hosting.IHostingEnvironment environment) 
        {
        userService=service;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var userlist=userService.GetAllUser();
            return View(userlist);  
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(User user)
        {
            if (user == null)
            {
                return View();
            }
            else
            {
                var files = Request.Form.Files;
                string dbpath = string.Empty;
                if (files.Count>0)
                {
                    string path = Environment.WebRootPath;
                    string fullpath = Path.Combine(path,"images",files[0].FileName);
                    dbpath = "images/" + files[0].FileName;
                    FileStream stream = new FileStream(fullpath,FileMode.Create);
                    files[0].CopyTo(stream);
                }
                user.Images = dbpath;
                var u = userService.Create(user);
                return RedirectToAction("Index","User");
            }
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var result=userService.Delete(id);
            return RedirectToAction("Index", "User");
        }
        public IActionResult Update(int id)
        {
            var user=userService.Update(id);
            return View(user);
        }
        [HttpPost]
        public IActionResult Update(User user)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            user.Images = dbpath;
            var u=userService.Update(user);
            return RedirectToAction("Index", "User");
        }
        [HttpGet]
        public IActionResult Read(int id)
        {
            var user=userService.Read(id);
            return View(user);
        }
    }
}
