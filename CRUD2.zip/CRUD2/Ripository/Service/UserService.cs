﻿using CRUD2.Models;
using CRUD2.Ripository.Contract;

namespace CRUD2.Ripository.Service
{
    public class UserService : IUser
    {
        private readonly AppDbContext dbcon;
        public UserService(AppDbContext db) 
        {
            dbcon = db;
        }
        public User Create(User user)
        {
            var u = new User() { 
            Name=user.Name, 
            Gender=user.Gender, 
            Email=user.Email,   
            Contact=user.Contact,
            Images=user.Images
            };
            dbcon.users.Add(u);
            dbcon.SaveChanges();
            return user;
        }

        public User Delete(int id)
        {
            var user = dbcon.users.SingleOrDefault(e=>e.Id==id);
            dbcon.users.Remove(user);
            dbcon.SaveChanges();
            return user;
        }

        public List<User> GetAllUser()
        {
            return dbcon.users.ToList();
        }

        public User Read(int id)
        {
            var user = dbcon.users.SingleOrDefault(e=>e.Id==id);
            return user;
        }

        public User Update(int id)
        {
            var user = dbcon.users.SingleOrDefault(e=>e.Id==id);
            return user;
        }

        public User Update(User user)
        {
            /*var u = new User();
            u.Id = user.Id;
                u.Name = user.Name;
                u.Gender = user.Gender;
                u.Email = user.Email;
                u.Contact = user.Contact;
                u.Images = user.Images;*/
                dbcon.users.Update(user);
                dbcon.SaveChanges();
                return user;
            
        }
    }
}
