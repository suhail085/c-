﻿using CRUD2.Models;

namespace CRUD2.Ripository.Contract
{
    public interface IUser
    {
        List<User> GetAllUser();
        User Create(User user);
        User Delete(int id);
        User Read(int id);
        User Update(int id);

        User Update(User user);
    }
}
